'use client'
// src/components/ui/glass/MotionTier.tsx
// Decides how much motion this device gets, once, and shares it.
//   full — capable desktop: WebGL aurora, cursor glow, tilt, particles
//   lite — touch / low-power / Save-Data: CSS motion only, no WebGL or cursor FX
//   off  — prefers-reduced-motion: final states, no movement
// Also mirrored to <html data-motion="…"> so CSS can tone itself down.
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { MotionConfig } from 'motion/react'

export type MotionTier = 'full' | 'lite' | 'off'

const Ctx = createContext<MotionTier>('lite')

type NavigatorHints = Navigator & {
  deviceMemory?: number
  connection?: { saveData?: boolean }
}

function detect(): MotionTier {
  if (typeof window === 'undefined') return 'lite'
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return 'off'
  const nav = navigator as NavigatorHints
  const coarse = window.matchMedia('(pointer: coarse)').matches
  const lowCpu = (nav.hardwareConcurrency ?? 8) <= 4
  const lowMem = (nav.deviceMemory ?? 8) <= 4
  const saveData = nav.connection?.saveData === true
  const narrow = window.innerWidth < 768
  if (coarse || lowCpu || lowMem || saveData || narrow) return 'lite'
  return 'full'
}

export function MotionProvider({ children }: { children: ReactNode }) {
  // Server + first client render agree on 'lite'; upgrade after mount (no hydration drift).
  const [tier, setTier] = useState<MotionTier>('lite')

  useEffect(() => {
    const update = () => {
      const t = detect()
      setTier(t)
      document.documentElement.dataset.motion = t
    }
    update()
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    mq.addEventListener('change', update)
    return () => mq.removeEventListener('change', update)
  }, [])

  return (
    <Ctx.Provider value={tier}>
      <MotionConfig reducedMotion="user">{children}</MotionConfig>
    </Ctx.Provider>
  )
}

export function useMotionTier(): MotionTier {
  return useContext(Ctx)
}
